package com.mayabo.finalandroidproject;

import androidx.appcompat.app.AppCompatActivity;

public class CurrencyConversionActivity extends AppCompatActivity {
}
